import java.util.ArrayList;

public class InventarioProductos {
    //Unicamente se debe usar ArrayList
    //Autor1: Garavi Lema

    private ArrayList<Producto> productos;

    public InventarioProductos() {
        productos = new ArrayList<Producto>();

        productos.add(new Producto(4, "Teclado Mecanico Gamer3.0", "TECLADO", 10));
        productos.add(new Producto(2, "Monitor Azus", "MONITOR", 10));
        productos.add(new Producto(6, "Monitor Samsumg ", "MONITOR", 10));
        productos.add(new Producto(3, "Procesador i7 13000g ", "PROCESADOR", 10));
        productos.add(new Producto(1, "Procesador Razen 7000gx", "PROCESADOR", 10));
        productos.add(new Producto(5, "Nvidia 3090", "GRAFICA", 10));
    }
    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public boolean modificcarProducto(int id, Producto producto){
        int inferior = 0;
        int superior = productos.size()-1;
        int centro ;
        while (inferior <= superior){
            centro = (inferior + superior)/2;
            if(productos.get(centro).getId() == producto.getId()){
                productos.set(centro, producto);
                return true;
            }else if(productos.get(centro).getId() < producto.getId()){
                superior = centro - 1;
            }else{
                inferior = centro + 1;
            }
        }
        return false;
    }
    public void inventario (int id, String nombre, String categoria, int cantidad){
        productos.add(new Producto(id, nombre, categoria, cantidad));
    }

}
