import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

//Escriba los nombres de los Autores
//Autor1: Garavi Lema
public class Ventana {
    private JTabbedPane Principal;
    private JPanel panel1;
    private JPanel Principal2;
    private JPanel Principal3;
    private JList lstMostrartodo;
    private JSpinner spinner1;
    private JButton btnEditar;
    private JTextField txtCantidad;
    private JButton btnMostrar;
    private JList list1;
    private JComboBox comboBox1;
    private JButton MOSTRARPORCATEGORIAButton;
    private InventarioProductos inventario;



    public Ventana() {
        inventario = new InventarioProductos();

        SpinnerNumberModel modelo = new SpinnerNumberModel(1, 1, 6, 1);
        spinner1.setModel(modelo);

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Obtener el ID del producto desde el Spinner
                    int idProducto = (Integer) spinner1.getValue();

                    // Obtener la nueva cantidad desde el TextField
                    int nuevaCantidad = Integer.parseInt(txtCantidad.getText().trim());

                    // Buscar el producto en el inventario
                    boolean encontrado = false;
                    for (Producto producto : inventario.getProductos()) {
                        if (producto.getId() == idProducto) {
                            // Crear un nuevo producto con los datos actualizados
                            Producto productoModificado = new Producto(
                                    producto.getId(),
                                    producto.getNombre(),
                                    producto.getCategoria(),
                                    nuevaCantidad
                            );

                            // Modificar el producto usando el método del inventario
                            inventario.modificcarProducto(idProducto, productoModificado);
                            encontrado = true;

                            JOptionPane.showMessageDialog(null,
                                    "Producto actualizado correctamente",
                                    "Éxito",
                                    JOptionPane.INFORMATION_MESSAGE);

                            // Limpiar el campo de cantidad
                            txtCantidad.setText("");
                            break;
                        }
                    }

                    if (!encontrado) {
                        JOptionPane.showMessageDialog(null,
                                "No se encontró un producto con el ID: " + idProducto,
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Por favor ingrese una cantidad válida",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener los productos del inventario
                ArrayList<Producto> listaProductos = inventario.getProductos();

                // Crear un modelo para el JList
                DefaultListModel<String> modelo = new DefaultListModel<>();

                // Agregar cada producto al modelo
                for (Producto producto : listaProductos) {
                    modelo.addElement(producto.toString());
                }

                // Establecer el modelo en el JList
                lstMostrartodo.setModel(modelo);
            }
        });


        MOSTRARPORCATEGORIAButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la categoría seleccionada del JComboBox
                String categoriaSeleccionada = (String) comboBox1.getSelectedItem();

                // Crear un modelo para el JList
                DefaultListModel<String> modelo = new DefaultListModel<>();

                // Filtrar productos por categoría
                int contador = 0;
                for (Producto producto : inventario.getProductos()) {
                    if (producto.getCategoria().equalsIgnoreCase(categoriaSeleccionada)) {
                        modelo.addElement(producto.toString());
                        contador++;
                    }
                }

                // Mostrar información
                if (contador == 0) {
                    modelo.addElement("No hay productos en esta categoría");
                }

                // Establecer el modelo en el JList
                list1.setModel(modelo);

                JOptionPane.showMessageDialog(null,
                        "Se encontraron " + contador + " producto(s) en la categoría: " + categoriaSeleccionada,
                        "Resultado",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
